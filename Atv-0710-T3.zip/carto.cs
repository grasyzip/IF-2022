using System;

public class Carto : Pagamento

{
    public override void Pagr()  {}

}