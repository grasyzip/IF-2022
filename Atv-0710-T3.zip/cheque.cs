using System;

public class Cheque : Pagamento 
{
    public override void Pagr() {}

}