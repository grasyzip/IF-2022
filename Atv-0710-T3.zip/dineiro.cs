using System;

public class Dineiro : Pagamento
{
    public override void Pagr() {}

}
