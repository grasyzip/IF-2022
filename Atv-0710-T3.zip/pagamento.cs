using System;

public abstract class Pagamento 
{  
    public double Valr { get; set; }

    public abstract void Pagr(); 

}
